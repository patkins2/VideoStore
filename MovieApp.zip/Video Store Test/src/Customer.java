import java.sql.*;
import java.util.*;

public class Customer {

	String customerName;

	int numberOfRentals;

	List<Movie> moviesRented = new ArrayList<Movie>();

	static Scanner input= new Scanner(System.in);
        
        

	public Customer(String customerName) 
	{
		this.customerName = customerName;
	}

	public void statement() throws SQLException, ClassNotFoundException 
	{
            displayTables(); // this will show the movies in the database
		while(true)
		{
                        System.out.print("\nPlease enter movie name : ");
			String movie=input.nextLine();
			System.out.print("Please enter number of rental days : ");
			int days = input.nextInt();

			int numberOfDays = days;
			Movie movieClass = new Movie(movie, numberOfDays);
			moviesRented.add(movieClass);
                        System.out.print("Do you want to add another movie? (y/n) ");
			if(!yesTo("Do you want to add another movie?"))
			{
				break;
			}
		}

		printStatement(); //prints the bill 

	}

	private void printStatement() throws SQLException 
	{
		double TotalCost = 0.00;

		System.out.println();

		System.out.println("---------------------------------------------------------------------------------------------");

		System.out.println("Billing Invoice");

		System.out.println();

		System.out.println("User: " + getCustomerName());

		System.out.println();

		for(Movie movie : moviesRented)
                {
			System.out.println("Movie Name : " + movie.getTitle() + " | Movie Rental Cost : $ " + movie.getPrice() +
					" | Movie Type : " + movie.getMovieType() + " | Number Of days : " + movie.getRentalClass().getNumberOfDays() +
                                        " | Cost : $ " + movie.getPrice()*movie.getRentalClass().numberOfDays);
			
			TotalCost = TotalCost + movie.getPrice()*movie.getRentalClass().numberOfDays;
		}

		System.out.println();
		System.out.print("Total Rental Cost = $ ");
                System.out.printf("%.2f", TotalCost); //formats the total to be an amount like "$5.00"
                System.out.println();
                
	}

	public static boolean yesTo(String prompt)//this is for if the user wants to add another movie
	{
		String response = input.nextLine().trim().toLowerCase();
		while (!response.equals("y") && !response.equals("n")) 
		{
                    response = input.nextLine().trim().toLowerCase();
		}
		return response.equals("y");
	}
        
        //setters and getters
        
	public String getCustomerName() 
	{
		return customerName;
	}

	public void setCustomerName(String customerName) 
	{
		this.customerName = customerName;
	}

	public int getNumberOfRentals() 
	{
		return numberOfRentals;
	}

	public void setNumberOfRentals(int numberOfRentals)
	{
		this.numberOfRentals = numberOfRentals;
	}

	public List<Movie> getMoviesRented() 
	{
		return moviesRented;
	}

	public void setMoviesRented(List<Movie> moviesRented)
	{
		this.moviesRented = moviesRented;
	}

    private void displayTables() throws SQLException, ClassNotFoundException //displays the database of movies
    {
            Class.forName("com.mysql.jdbc.Driver");
            Connection myConn = DriverManager.getConnection("jdbc:mysql://localhost:3306/users", "root", "Sunshine03!");
            System.out.println("Available Movies:");
            Statement ps = myConn.createStatement();
            ResultSet rs1 = ps.executeQuery("SELECT * from regular");
            System.out.print("Regular Movies: ");
            while(rs1.next())
            {   
                String titleRegular = rs1.getString("Title");
                System.out.print(titleRegular + ", " );
            }
            ResultSet rs2 = ps.executeQuery("Select * from children");
            System.out.print("\nKids Movies: ");
            while(rs2.next())
            {
                String titleChildren = rs2.getString("Title");
                System.out.print(titleChildren + ", ");

            }
            ResultSet rs3 = ps.executeQuery("Select * from newreleases");
            System.out.print("\nNew Movies: ");
            while(rs3.next())
            {
                String titleNew = rs3.getString("Title");
                System.out.print(titleNew + ", ");
            }
            myConn.close();
    }
}
