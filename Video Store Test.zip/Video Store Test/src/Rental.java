public class Rental 
{
	int numberOfDays;
	int frequentRenterPoints;
	String movieType;

	public Rental(int days, String movieType) 
	{
		this.numberOfDays = days;
		this.movieType = movieType;
	}

	public int getNumberOfDays() 
	{
		return numberOfDays;
	}

	public void setNumberOfDays(int numberOfDays) 
	{
		this.numberOfDays = numberOfDays;
	}

	public String getMovieType() 
	{
		return movieType;
	}

	public void setMovieType(String movieType) 
	{
		this.movieType = movieType;
	}
}