import java.util.*;
import java.sql.*;
public class RentalBilling 
{
	public static void main(String[] args) throws SQLException, ClassNotFoundException
	{       
                Class.forName("com.mysql.jdbc.Driver");
		Scanner input = new Scanner(System.in);
                String answer = "";
                String sql = "insert into Accounts "
			+ " (UserEmail, UserPassword) values(?, ?)";
                String email = "";
                String password = "";
                
                Connection myConn = DriverManager.getConnection("jdbc:mysql://localhost:3306/users", "root", "Sunshine03!");                        
                ResultSet rs;
                PreparedStatement myStmt = myConn.prepareStatement(sql);
                        
                while(!answer.equals("n") && !answer.equals("y") )
                {
                    System.out.print("Do you have an account? (Y/N): ");
                    answer = input.nextLine();
                
                    if(answer.toLowerCase().equals("n"))
                    {
                        System.out.println("Please enter the email and password for your new account.");
                        System.out.print("Email: ");
                        email = input.nextLine();
                        System.out.print("Password: ");
                        password = input.nextLine();
                      
                        
                        
                        myStmt.setString(1, email);
                        myStmt.setString(2, password);
                        
                        myStmt.executeUpdate();
                        

                    }
                    else if(answer.toLowerCase().equals("y"))
                    {
                        System.out.print("\nEmail: ");
                        email = input.nextLine();
                        System.out.print("\nPassword: ");
                        password = input.nextLine();
                        String queryCheck = "SELECT * from accounts WHERE UserEmail = ?";
                        PreparedStatement ps = myConn.prepareStatement(queryCheck);
                        ps.setString(1, email);
                        rs = ps.executeQuery();  
                        if(!rs.absolute(1))
                        {
                            System.out.println("You do not have an account. Please create one.");
                            answer = "x"; //restarts the loop
                        }
                        else
                        {
                            System.out.println("Log in successful...");
                            break;
                        }
                        
                    }
                    else
                    {
                        System.out.println("Invalid input. Please try again.");
                    }
                }
		Customer customer = new Customer(email);
                
		customer.statement();
	}
}