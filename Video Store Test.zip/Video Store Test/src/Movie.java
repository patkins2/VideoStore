
import java.sql.*;
import java.util.ArrayList;

public class Movie {

    
    String title;
    double price;
    String movieType;
    Rental rentalClass;
    
    ArrayList<String> regularMovies = new ArrayList<String>();
    ArrayList<String> childrenMovies = new ArrayList<String>();
    ArrayList<String> newMovies = new ArrayList<String>();
    //double value = 1.00;

    public Movie(String title, int numberOfDays) throws SQLException 
    {
        this.title = title;
        movieType = getMovieType();
        price = getPricing(this.movieType);
        rentalClass = new Rental(numberOfDays, movieType);

    }
    
    public String getTitle() 
    {
        return title;
    }

    public void setTitle(String title) 
    {
        this.title = title;
    }

    public double getPrice() 
    {
        return price;
    }

    public Rental getRentalClass() 
    {
        return rentalClass;
    }

    public double getPricing(String movieType) 
    {
        //double value = 0.00;

        if (movieType.equals("Children Movies"))
        {
            //value += 0.75;
            return 0.75;
        } 
        else if (movieType.equals("New Release")) 
        {
            //value += 1.50;
            return 1.50;
        } 
        else 
        {
            //value += 1.00;
            return 1.00;
        }

        //return value;
        //return 1;
    }
    
    

    public String getMovieType() throws SQLException 
    {

        String queryCheck1 = "SELECT * from regular WHERE title = ?";
        String queryCheck2 = "SELECT * from children WHERE title = ?";
        String queryCheck3 = "SELECT * from newreleases WHERE title = ?";
        Connection myConn = DriverManager.getConnection("jdbc:mysql://localhost:3306/users", "root", "Sunshine03!");
        PreparedStatement stmtReg = myConn.prepareStatement(queryCheck1);
        PreparedStatement stmtChild = myConn.prepareStatement(queryCheck2);
        PreparedStatement stmtNew = myConn.prepareStatement(queryCheck3);
        stmtReg.setString(1, this.title);
        stmtChild.setString(1, this.title);
        stmtNew.setString(1, this.title);
        ResultSet rsReg = stmtReg.executeQuery();
        ResultSet rsChild = stmtChild.executeQuery();
        ResultSet rsNew = stmtNew.executeQuery();
        if(rsNew.absolute(1))
        {
            return "New Release";
        }
        else if(rsChild.absolute(1))
        {
            return "Children Movie";
        }
        else if(rsReg.absolute(1)) 
        {
            return "Regular Movie";
        }
        else
        {
            System.out.println("Movie is not available, please try again");
            System.exit(0);
            return "exit";
        }
    }

    
}