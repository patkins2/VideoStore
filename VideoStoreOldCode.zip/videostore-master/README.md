videostore
==========

The videostore example from Episode 3 of cleancoders.com.
Based upon, but not identical to, the first chapter of Martin Fowler's classic book: Refactoring.
